# CSS Only sliding button

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/abKyJNJ](https://codepen.io/t_afif/pen/abKyJNJ).

